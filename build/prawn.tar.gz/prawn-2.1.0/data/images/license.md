All images distributed with Prawn need to be freely distributable under
a license that is compatible with our own (see LICENSE and COPYING files).

It is our understanding that all files in this folder are compatible
with our licensing, but if you notice any problems, please
file an issue in our tracker on Github and we will promptly address it:

https://github.com/prawnpdf/prawn/issues
