# PDF::Core

[![Build Status](https://travis-ci.org/prawnpdf/prawn.png?branch=master)](https://travis-ci.org/prawnpdf/prawn)
![Maintained: yes](https://img.shields.io/badge/maintained-yes-brightgreen.png)

This is an experimental gem that extracts low-level PDF functionality from
Prawn. More details to come soon!
